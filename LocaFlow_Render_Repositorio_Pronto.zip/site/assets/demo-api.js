/* Demonstração pública estática, sem servidor e SEM dados reais.
   Toda ação modifica apenas estruturas temporárias deste navegador. */
(() => {
  let seq = 100;
  const id = p => `${p}-${++seq}`;
  const today = new Date();
  const future = n => {const d = new Date(today);d.setDate(d.getDate()+n);d.setHours(14,0,0,0);return d.toISOString()};
  const company={id:'demo-tenant',name:'Premium Eventos (Fictícia)',slug:'premium-demo'};
  const user={id:'demo-owner',name:'Gestor Demo',email:'demo@exemplo.invalid',role:'owner',company};
  const products=[
    {id:'p1',name:'Cadeira branca',description:'Cadeira para festas e eventos',category:'Mobiliário',quantity:200,unit_price_cents:500,prep_minutes:60,return_minutes:120,active:1},
    {id:'p2',name:'Mesa redonda',description:'Mesa para 6 a 8 convidados',category:'Mobiliário',quantity:40,unit_price_cents:2000,prep_minutes:60,return_minutes:120,active:1},
    {id:'p3',name:'Caixa de som amplificada',description:'Som profissional para eventos',category:'Áudio',quantity:8,unit_price_cents:15000,prep_minutes:120,return_minutes:120,active:1},
    {id:'p4',name:'Kit de iluminação LED',description:'Iluminação ambiente para eventos',category:'Iluminação',quantity:6,unit_price_cents:12000,prep_minutes:90,return_minutes:90,active:1},
  ];
  const customers=[
    {id:'c1',name:'Cliente Exemplo A',phone:'(00) 00000-0000',email:'cliente-a@exemplo.invalid'},
    {id:'c2',name:'Cliente Exemplo B',phone:'(00) 00000-0000',email:'cliente-b@exemplo.invalid'},
  ];
  const quotes=[];
  const rentals=[];
  const staff=[{id:'demo-owner',name:'Gestor Demo',email:'demo@exemplo.invalid',role:'owner'}];
  const audits=[];
  const log=(action,kind,object_id)=>audits.unshift({id:id('a'),created_at:new Date().toISOString(),action,object_type:kind,object_id,user_id:'demo-owner'});
  const qcost=q=>Math.max(0,q.items.reduce((sum,i)=>sum+i.unit_price_cents*i.quantity,0)+(q.fee_cents||0)-(q.discount_cents||0));
  const lookup=p=>products.find(x=>x.id===p);
  const asQuote=(q)=>({...q,total_cents:qcost(q),customer_name:customers.find(c=>c.id===q.customer_id)?.name||'Cliente demo'});
  const asRental=(r)=>({...r,items:r.items.map(x=>({...x,name:lookup(x.product_id)?.name||'Produto'}))});
  function makeQuote(body){
    const items=body.items.map(i=>{
      const p=lookup(i.product_id);if(!p)throw Error('Equipamento não encontrado');
      if(!Number.isInteger(i.quantity)||i.quantity<1)throw Error('Quantidade inválida');
      return {id:id('qi'),product_id:p.id,quantity:i.quantity,unit_price_cents:p.unit_price_cents,name:p.name};
    });
    if(!(Date.parse(body.end_at)>Date.parse(body.start_at)))throw Error('Informe um período válido');
    const q={id:id('q'),customer_id:body.customer_id,code:`ORC-DEMO-${seq}`,start_at:body.start_at,end_at:body.end_at,status:'draft',fee_cents:body.fee_cents||0,discount_cents:body.discount_cents||0,deposit_cents:body.deposit_cents||0,public_token:id('link'),items,created_at:new Date().toISOString()};
    quotes.unshift(q); log('quote.created','quote',q.id);return asQuote(q);
  }
  function available(pid,start,end){
    const p=lookup(pid); if(!p)throw Error('Equipamento não encontrado');
    const count=rentals.filter(r=>!['cancelled','closed'].includes(r.status)&&Date.parse(r.start_at)<Date.parse(end)&&Date.parse(start)<Date.parse(r.end_at))
      .flatMap(r=>r.items).filter(x=>x.product_id===pid).reduce((n,x)=>n+x.quantity,0);
    return Math.max(0,p.quantity-count);
  }
  const sample=makeQuote({customer_id:'c1',start_at:future(5),end_at:future(6),items:[{product_id:'p1',quantity:60},{product_id:'p2',quantity:10},{product_id:'p3',quantity:2}],fee_cents:18000,discount_cents:0,deposit_cents:25000});
  const sr={id:'r1',quote_id:sample.id,start_at:sample.start_at,end_at:sample.end_at,code:sample.code,customer_name:'Cliente Exemplo A',total_cents:sample.total_cents,deposit_cents:sample.deposit_cents,status:'confirmed',items:sample.items.map(i=>({id:id('ri'),product_id:i.product_id,quantity:i.quantity,received_qty:0})),payments:[],created_at:new Date().toISOString()};
  rentals.push(sr);quotes[0].status='confirmed';
  makeQuote({customer_id:'c2',start_at:future(10),end_at:future(11),items:[{product_id:'p4',quantity:1}],fee_cents:8000,deposit_cents:5000});
  async function demoApi(path,method='GET',body){
    // Public demonstration is never a real payment, contract or reservation service.
    if(path==='/me')return {...user};
    if(path==='/dashboard')return {products:products.length,customers:customers.length,quotes:quotes.length,rentals:rentals.length,active_rentals:rentals.filter(r=>!['closed','cancelled'].includes(r.status)).length};
    if(path==='/products'){
      if(method==='GET')return [...products];
      const p={id:id('p'),...body,active:1};products.unshift(p);log('product.created','product',p.id);return {id:p.id};
    }
    if(path==='/customers'){
      if(method==='GET')return [...customers];
      const c={id:id('c'),...body};customers.unshift(c);log('customer.created','customer',c.id);return {id:c.id};
    }
    if(path.startsWith('/availability?')){
      const p=new URLSearchParams(path.split('?')[1]);return {available:available(p.get('product_id'),p.get('start_at'),p.get('end_at'))};
    }
    if(path==='/quotes'){
      if(method==='GET')return quotes.map(asQuote);
      return makeQuote(body);
    }
    if(path==='/rentals'&&method==='GET')return rentals.map(asRental);
    const confirm=path.match(/^\/quotes\/([^/]+)\/confirm$/);
    if(confirm){
      const q=quotes.find(x=>x.id===confirm[1]);if(!q||q.status!=='draft')throw Error('Orçamento não está disponível');
      for(const i of q.items){const free=available(i.product_id,q.start_at,q.end_at);if(free<i.quantity)throw Error(`Estoque insuficiente: ${lookup(i.product_id).name}. Disponíveis: ${free}`)}
      q.status='confirmed';const r={id:id('r'),quote_id:q.id,code:q.code,customer_name:customers.find(x=>x.id===q.customer_id)?.name,start_at:q.start_at,end_at:q.end_at,total_cents:qcost(q),deposit_cents:q.deposit_cents,status:'confirmed',items:q.items.map(i=>({id:id('ri'),product_id:i.product_id,quantity:i.quantity,received_qty:0})),payments:[],created_at:new Date().toISOString()};
      rentals.unshift(r);log('rental.confirmed','rental',r.id);return asRental(r);
    }
    const cancel=path.match(/^\/rentals\/([^/]+)\/cancel$/);
    if(cancel){const r=rentals.find(x=>x.id===cancel[1]);if(!r||!['confirmed','prepared'].includes(r.status))throw Error('Esta locação não pode ser cancelada nesta etapa');r.status='cancelled';log('rental.cancelled','rental',r.id);return {status:'cancelled',financial_review_required:r.payments.length>0};}
    const transition=path.match(/^\/rentals\/([^/?]+)\/transition\?action=(\w+)$/);
    if(transition){
      const r=rentals.find(x=>x.id===transition[1]), action=transition[2];if(!r)throw Error('Locação não encontrada');
      const map={prepare:['confirmed','prepared'],dispatch:['prepared','dispatched'],deliver:['dispatched','delivered'],receive:['delivered','inspection'],close:['inspection','closed']};
      const pair=map[action];if(!pair||r.status!==pair[0])throw Error('Etapa indisponível');
      if(action==='close'&&r.items.some(i=>i.received_qty<i.quantity))throw Error('Existem itens não devolvidos');
      r.status=pair[1];log(`rental.${action}`,'rental',r.id);return asRental(r);
    }
    const ret=path.match(/^\/rentals\/([^/]+)\/return-item$/);
    if(ret){const r=rentals.find(x=>x.id===ret[1]);if(!r||r.status!=='inspection')throw Error('Aguardando conferência');const i=r.items.find(x=>x.product_id===body.product_id);if(!i||i.received_qty+body.quantity>i.quantity)throw Error('Quantidade inválida');i.received_qty+=body.quantity;log('rental.return','rental',r.id);return asRental(r);}
    if(path==='/payments'&&method==='POST'){
      const r=rentals.find(x=>x.id===body.rental_id);if(!r)throw Error('Locação não encontrada');
      if(r.payments.find(x=>x.reference===body.reference))throw Error('Referência repetida');
      const paid=r.payments.filter(p=>p.kind===body.kind).reduce((sum,p)=>sum+p.amount_cents,0);
      if(body.kind==='rent'&&paid+body.amount_cents>r.total_cents)throw Error('Valor supera total da locação');
      if(body.kind==='deposit'&&paid+body.amount_cents>r.deposit_cents)throw Error('Valor supera a caução');
      r.payments.push({id:id('pay'),kind:body.kind,amount_cents:body.amount_cents,reference:body.reference,created_at:new Date().toISOString()});
      log('payment.recorded-demo','payment',r.id);return {status:'simulated',bank_confirmed:false};
    }
    if(path==='/staff'){
      if(method==='GET')return [...staff];
      const s={id:id('user'),name:body.name,email:body.email,role:body.role};staff.push(s);log('staff.created-demo','staff',s.id);return s;
    }
    if(path==='/audit')return [...audits];
    const catalog=path.match(/^\/public\/([^/]+)\/catalog$/);
    if(catalog)return {tenant:company,products:products.map(({id,name,description,category,unit_price_cents})=>({id,name,description,category,unit_price_cents})),price_disclaimer:'Valores fictícios, demonstração sem transações reais'};
    const publicQ=path.match(/^\/public\/([^/]+)\/quote$/);
    if(publicQ){const c={id:id('c'),...body.customer};customers.push(c);const q=makeQuote({...body,customer_id:c.id});return {code:q.code,tracking_token:q.public_token,status:'draft'};}
    const track=path.match(/^\/track\/(.+)$/);
    if(track){const q=quotes.find(x=>x.public_token===decodeURIComponent(track[1]));if(!q)throw Error('Pedido não encontrado nesta sessão');return {code:q.code,status:q.status,rental_status:rentals.find(x=>x.quote_id===q.id)?.status||null};}
    if(path==='/auth/login')return {token:'demo',role:'owner'};
    if(path==='/auth/register')return {token:'demo',role:'owner',tenant:company};
    throw Error(`Funcionalidade não incluída nesta prévia: ${path}`);
  }
  window.demoApi=demoApi;
})();
