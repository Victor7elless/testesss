# LocaFlow — Demonstração visual para Render

Este é um site estático ilustrativo **com dados fictícios**, não o backend Python do LocaFlow v0.2. Não use dados pessoais reais.

O `render.yaml` é um blueprint de **Static Site** do Render, para hospedar uma demonstração sem expor a API local ainda não homologada para uso público.

## Publicação

1. Suba os arquivos desta pasta para um repositório Git.
2. Em Render, use **New > Blueprint** e conecte o repositório contendo `render.yaml`.
3. Confirme a criação do serviço estático de demonstração.
4. Espere o Render exibir o URL `onrender.com` do projeto; verifique se a página e o portal `/portal/premium-demo/` abrem.

> O upload do ZIP no Render não publica automaticamente o serviço. A conexão com Git/Render ainda é necessária. Para publicar o SaaS completo, é preciso hardening, banco PostgreSQL e configuração de sessões.
